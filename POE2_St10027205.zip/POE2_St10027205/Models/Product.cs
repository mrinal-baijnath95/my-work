﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace POE2_St10027205.Models;

public partial class Product
{
    public int ProductId { get; set; }
    
    public int? UserId { get; set; }
  
    public string ProductName { get; set; } = null!;
    
    public string? Category { get; set; }
    
    public DateOnly? ProductionDate { get; set; }

    public virtual Users3? User { get; set; }
}
