﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace POE2_St10027205.Models;

public partial class Users3
{
    public int UserId { get; set; }
   
    public string Username { get; set; } = null!;
    
    public string UserPassword { get; set; } = null!;

    public string UserRole { get; set; } = null!;
   
    public string? FirstName { get; set; }
    
    
    public string? LastName { get; set; }
   
    
    public string? Email { get; set; }
    
    public string? Phone { get; set; }

    public string? Address { get; set; }

    public DateTime CreatedAt { get; set; }

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
