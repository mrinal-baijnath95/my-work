﻿




using BCrypt.Net;

namespace POE2_St10027205.Models
{
    public class PasswordClass
    {
        //Code atrribution 
        //Source: Stack Overflow 
        //Accessed 27 May 2024
        //Link:https://stackoverflow.com/questions/873403/net-implementation-of-bcrypt
        public static string EncryptPassword { get; set; }

        public static string SetPassword(string password)
        {
            EncryptPassword = Encrypt(password);
            return EncryptPassword;
        }

        public static string Encrypt(string plainText)
        {
            // Generate a salt and hash the password
            string salt = BCrypt.Net.BCrypt.GenerateSalt();
            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(plainText, salt);
            return hashedPassword;
        }

        public static bool VerifyPassword(string password, string hashedPassword)
        {
            // Verify the password against the hashed password
            return BCrypt.Net.BCrypt.Verify(password, hashedPassword);
        }
    }
}

