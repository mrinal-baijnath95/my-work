﻿namespace POE2_St10027205.Models
{
    public class UserCurrent
    {
        public static string usercurrent {  get; set; }

    }
}
