﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using POE2_St10027205.Models;

namespace POE2_St10027205.Controllers
{
    public class RegisterController : Controller
    {
        private readonly Part27311Context _context;
        
        public RegisterController(Part27311Context context)
        {
            _context = context;
        }
        
        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Index(Users3 users3, string Password)
        {
            if (ModelState.IsValid && users3.UserPassword == Password)
            {
                if (_context.Users3s.Any(u => u.Username == users3.Username || u.Email == users3.Email))
                {
                    ModelState.AddModelError("", "Username or Email already exists.");
                    return View(users3);
                }
                // Enrypt the password before saving to the database
                users3.UserPassword = PasswordClass.SetPassword(Password);
                users3.CreatedAt = DateTime.Now;

                // Save the user to the database
                _context.Users3s.Add(users3);
                _context.SaveChanges();

                return RedirectToAction("Index", "Login");

            }


            return RedirectToAction("Index", "Login");
        }




    }
}
