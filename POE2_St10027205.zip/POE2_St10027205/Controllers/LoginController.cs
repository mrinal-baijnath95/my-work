﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using POE2_St10027205.Models;

namespace POE2_St10027205.Controllers
{
    public class LoginController : Controller
    {

        private readonly Part27311Context _context;

        public LoginController(Part27311Context context)
        {
            _context = context;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(string username, string password)
        {
            var user = _context.Users3s.FirstOrDefault(u => u.Username == username);

            // Check if the user exists and the password is correct
            if (user != null && PasswordClass.VerifyPassword(password, user.UserPassword))
            {
                if (user.UserRole == "Farmer")
                {
                    UserCurrent.usercurrent = user.Username;
                    return RedirectToAction("Index", "FarmerProducts");
                }
                else                {
                   UserCurrent.usercurrent = user.Username;
                    return RedirectToAction("Index", "EmployeeDash");
                }

            }
            return View();
        }






    }
}
