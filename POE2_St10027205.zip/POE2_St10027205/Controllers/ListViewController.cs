﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using POE2_St10027205.Models;

namespace POE2_St10027205.Controllers
{

    public class ListViewController : Controller
    {
        private readonly Part27311Context _context;
        public IActionResult Index()
        {
            return View();
        }
        public ListViewController(Part27311Context context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index(string? productType, DateOnly? startDate, DateOnly? endDate)
        {
            var query = _context.Products.Include(p => p.User).AsQueryable();

            if (!string.IsNullOrEmpty(productType))
            {
                query = query.Where(p => p.Category == productType);
            }

            if (startDate.HasValue)
            {
                query = query.Where(p => p.ProductionDate >= startDate);
            }

            if (endDate.HasValue)
            {
                query = query.Where(p => p.ProductionDate <= endDate);
            }
            var model = new ProductsFiltered
            {
                TypeProduct = productType,
                StartDate = startDate,
                EndDate = endDate,
                Products = await query.ToListAsync()
            };

            return View(model);
        }

    }
    }
