﻿using Microsoft.AspNetCore.Mvc;

namespace POE2_St10027205.Controllers
{
    public class EmployeeDashController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
    }
}
